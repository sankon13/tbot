# -*- coding: utf-8 -*-
"""ZAKUP — Telegram-бот поиска поставщиков: запрос -> бриф -> выбор источника -> список со ссылками.

Хранение — Google Таблица (sheets.py), поиск — коннекторы (searchers/),
веб-страница со статусами — в этом же процессе (web/dashboard.py).
"""
import asyncio
import logging
import os

from aiohttp import web
from aiogram import Bot, Dispatcher, F
from aiogram.filters import Command
from aiogram.types import Message, CallbackQuery
from aiogram.utils.keyboard import InlineKeyboardBuilder
from io import BytesIO

import config
import llm
from searchers import glm_web, yandex
from searchers.base import SOURCES
from sheets import Sheets
from web import dashboard

logging.basicConfig(level=logging.INFO)

# Контекст диалога: user_id -> {"expect": "brief", "draft": {...}}
dialogs: dict[int, dict] = {}


def kb(buttons: list[tuple[str, str]], cols: int = 1) -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    for text, data in buttons:
        b.button(text=text, callback_data=data)
    b.adjust(cols)
    return b.as_markup()


class ZakupBot:
    def __init__(self):
        self.bot = Bot(token=config.TELEGRAM_BOT_TOKEN)
        self.dp = Dispatcher()
        self.sheets = Sheets()
        self.sheets.ensure_structure()
        self.users = dict(config.USERS)
        self.users.update(self.sheets.load_users())
        self.pending: dict[int, dict] = {}   # ждущие решения заявки на доступ
        self.denied: set[int] = set()        # отклонённые (до перезапуска)
        self._register()

    def _register(self):
        self.dp.message(Command("start"))(self.cmd_start)
        self.dp.message(Command("zaprosy", "requests", "запросы"))(self.cmd_requests)
        self.dp.callback_query(F.data.startswith("go:"))(self.on_go)
        self.dp.callback_query(F.data.startswith("acc:"))(self.on_access_decision)
        self.dp.message(F.voice)(self.on_voice)
        self.dp.message()(self.on_message)

    async def handle_update(self, request):
        from aiogram.types import Update
        if request.headers.get("X-Telegram-Bot-Api-Secret-Token") != config.WEBHOOK_SECRET:
            return web.Response(status=403)
        update = Update.model_validate(await request.json(), context={"bot": self.bot})
        await self.dp.feed_update(self.bot, update)
        return web.Response(text="ok")

    async def run(self):
        app = web.Application()
        dashboard.add_routes(app, self.sheets)
        if config.WEBHOOK_URL:
            app.router.add_post(config.WEBHOOK_PATH, self.handle_update)
            await self.bot.set_webhook(
                config.WEBHOOK_URL.rstrip("/") + config.WEBHOOK_PATH,
                secret_token=config.WEBHOOK_SECRET,
                allowed_updates=["message", "callback_query"],
                drop_pending_updates=False,
            )
            logging.info("webhook set: %s", config.WEBHOOK_URL)
        runner = web.AppRunner(app)
        await runner.setup()
        port = int(os.environ.get("PORT", 8080))
        await web.TCPSite(runner, "0.0.0.0", port).start()
        logging.info("dashboard on :%s", port)
        if not config.WEBHOOK_URL:
            await self.bot.delete_webhook(drop_pending_updates=True)
            await self.dp.start_polling(self.bot)
        else:
            await asyncio.Event().wait()  # работаем как веб-сервер

    # ---------- доступ ----------
    async def check_access(self, m: Message) -> bool:
        uid = m.from_user.id
        if uid in self.users:
            return True
        if uid in self.denied:
            await m.answer("Доступ не одобрен. Обратитесь к Александру.")
            return False
        if uid in self.pending:
            await m.answer("Заявка уже отправлена Александру, ждите решения.")
            return False
        u = m.from_user
        who = u.full_name + (f" (@{u.username})" if u.username else "")
        self.pending[uid] = {"name": u.full_name}
        for aid in config.ADMIN_IDS:
            try:
                await self.bot.send_message(
                    aid,
                    f"🔔 Новый пользователь просит доступ к боту:\n{who}\nID: `{uid}`\n\nОткрыть доступ?",
                    reply_markup=kb([("✅ Да, открыть", f"acc:{uid}:yes"), ("❌ Нет", f"acc:{uid}:no")]),
                )
            except Exception:
                logging.exception("не удалось отправить заявку админу %s", aid)
        await m.answer("У вас пока нет доступа 🙁 Заявка отправлена Александру — как одобрит, бот вам ответит.")
        return False

    async def on_access_decision(self, q: CallbackQuery):
        await q.answer()
        try:
            _, uid_s, dec = q.data.split(":")
            uid = int(uid_s)
        except ValueError:
            return
        p = self.pending.pop(uid, None)
        if p is None:
            await q.message.edit_text("Заявка уже обработана.")
            return
        name = p.get("name") or f"Пользователь {uid}"
        if dec == "yes":
            self.sheets.add_user(uid, name)
            self.users[uid] = name
            await q.message.edit_text(f"✅ Доступ открыт: {name} ({uid}).")
            try:
                await self.bot.send_message(
                    uid, "✅ Александр открыл вам доступ! Напишите, каких поставщиков найти — "
                         "например: «Нужны исполнители по стяжке пола в Казани».")
            except Exception:
                pass
        else:
            self.denied.add(uid)
            await q.message.edit_text(f"❌ Отклонено: {name} ({uid}).")
            try:
                await self.bot.send_message(uid, "❌ В доступе отказано.")
            except Exception:
                pass

    # ---------- команды ----------
    async def cmd_start(self, m: Message):
        await m.answer(
            f"Привет, {self.users.get(m.from_user.id, m.from_user.first_name)}! 👋\n\n"
            "Я ищу поставщиков: исполнителей работ и продавцов материалов.\n\n"
            "Просто напиши или продиктуй запрос, например:\n"
            "«Нужны исполнители по стяжке пола в Казани»\n"
            "«Найди на Авито бригаду отделочников»\n"
            "«Где купить облицовочный кирпич, 5000 шт»\n\n"
            "Я уточню детали, предложу где искать (Авито, Яндекс Услуги, весь интернет) "
            "и пришлю список со ссылками. Все запросы и результаты — на веб-странице.\n\n"
            "/zaprosy — мои последние запросы и статусы.")

    async def cmd_requests(self, m: Message):
        rows = [r for r in self.sheets.all_requests() if r and r[0].strip()][-10:]
        if not rows:
            await m.answer("Запросов пока нет. Напиши, кого найти — и я начну поиск.")
            return
        lines = [f"№{r[0]} · {r[1]} · {r[8] if len(r) > 8 else '?'} · {r[3][:60]}"
                 f" ({r[7] if len(r) > 7 else '?'}{', ' + r[9] + ' шт' if len(r) > 9 and r[9] not in ('', '0') else ''})"
                 for r in rows]
        await m.answer("Последние запросы:\n" + "\n".join(reversed(lines)))

    # ---------- голосовые ----------
    async def on_voice(self, m: Message):
        if not await self.check_access(m):
            return
        note = await m.answer("🎤 Распознаю…")
        buf = BytesIO()
        await self.bot.download(m.voice, destination=buf)
        try:
            text = await asyncio.to_thread(
                llm.transcribe, buf.getvalue(),
                getattr(m.voice, "file_name", None) or "voice.ogg")
        except Exception:
            logging.exception("transcribe failed")
            text = ""
        if not text:
            await note.edit_text("Не удалось распознать голосовое 🙁 Напишите запрос текстом.")
            return
        await note.edit_text(f"🎤 Слышу: «{text}»")
        await self.start_request(m.from_user.id, self.users.get(m.from_user.id, "?"), text, m.answer)

    # ---------- основная обработка ----------
    async def on_message(self, m: Message):
        if not await self.check_access(m):
            return
        uid = m.from_user.id
        text = (m.text or "").strip()
        if not text:
            return
        await self.start_request(uid, self.users.get(uid, "?"), text, m.answer)

    async def start_request(self, uid: int, author: str, text: str, send):
        """Разбирает текст запроса в бриф и показывает выбор источника."""
        brief = await asyncio.to_thread(llm.parse_request, text)
        if brief.get("chat"):
            dialogs.pop(uid, None)
            return await send(llm.chat(text))
        dialogs[uid] = {"expect": "brief", "draft": {"text": text, "author": author, "brief": brief}}
        city = brief.get("city") or "—"
        volume = brief.get("volume") or "—"
        if brief.get("source"):
            buttons = [(f"✅ Искать: {SOURCES[brief['source']]}", f"go:{brief['source']}"),
                       ("🌐 Весь интернет", "go:web"),
                       ("❌ Отмена", "go:cancel")]
        else:
            buttons = [("Авито", "go:avito"), ("Яндекс Услуги", "go:yandex_uslugi"),
                       ("🌐 Весь интернет", "go:web"), ("🌍 Все источники", "go:all"),
                       ("❌ Отмена", "go:cancel")]
        await send(
            "🔎 Запрос понят:\n"
            f"• Что: {brief['what']}\n"
            f"• Тип: {brief['type']}\n"
            f"• Город: {city}\n"
            f"• Объём: {volume}\n\n"
            "Где искать?",
            reply_markup=kb(buttons, cols=2))

    async def on_go(self, q: CallbackQuery):
        await q.answer()
        uid = q.from_user.id
        d = dialogs.get(uid)
        if not d or d.get("expect") != "brief":
            await q.message.edit_text("Диалог уже закрыт — напишите запрос заново.")
            return
        choice = q.data[3:]
        if choice == "cancel":
            dialogs.pop(uid, None)
            await q.message.edit_text("❌ Отменено. Напишите новый запрос, когда понадобится.")
            return
        sources = ["avito", "yandex_uslugi", "web"] if choice == "all" else [choice]
        labels = " + ".join(SOURCES[s] for s in sources)
        dialogs.pop(uid, None)
        draft = d["draft"]
        await q.message.edit_text(f"🔎 Ищу: {draft['brief']['what']} ({labels})…")
        result = await asyncio.to_thread(
            self._search_pipeline, uid, draft, choice, labels, sources)
        await self._send_results(q.message.edit_text, q.message.answer, *result)

    # ---------- поиск (блокирующий, вызывается в отдельном потоке) ----------
    @staticmethod
    def search_source(brief: dict, source: str) -> list:
        """Основной поиск — Yandex Search API; нет ключа или ошибка -> веб-поиск GLM."""
        try:
            if yandex.configured():
                return yandex.search_yandex(brief, source)
        except Exception:
            logging.exception("yandex search failed, fallback to GLM")
        return glm_web.search_web(brief, source)

    def _search_pipeline(self, uid: int, draft: dict, choice: str, labels: str, sources: list[str]):
        brief = draft["brief"]
        no = self.sheets.add_request(draft["author"], draft["text"], brief, labels)
        raw = []
        try:
            for src in sources:
                raw.extend(self.search_source(brief, src))
            ranked = llm.rank_results(brief, raw)
            # i в ответе LLM — 1-based индекс по общему списку raw
            final = [(raw[it["i"] - 1], it["name"], it["why"]) for it in ranked]
            # защитный дедуп по ссылке
            seen, uniq = set(), []
            for sup, name, why in final:
                key = sup.url.rstrip("/").lower()
                if key not in seen:
                    seen.add(key)
                    uniq.append((sup, name, why))
            final = uniq
            self.sheets.add_suppliers(no, [sup for sup, _, _ in final])
            status = "Есть результаты" if final else "Нет результатов"
            self.sheets.update_request(no, status, found=len(final))
            return no, final, labels, None
        except Exception as e:
            logging.exception("search failed")
            self.sheets.update_request(no, "Ошибка", note=str(e))
            return no, [], labels, str(e)

    async def _send_results(self, edit, send, no: int, final: list, labels: str, error: str | None):
        if error:
            await edit(f"⚠️ По запросу №{no} поиск не удался: {error[:200]}.\n"
                       "Попробуйте ещё раз — или я посмотрю логи.")
            return
        if not final:
            await edit(f"🤷 По запросу №{no} ничего подходящего не нашёл ({labels}).\n"
                       "Попробуйте переформулировать или выбрать другой источник.")
            return
        header = f"✅ Запрос №{no} — нашёл {len(final)} поставщиков ({labels}):\n\n"
        items = [f"{i}. {name}\n{why}\n{sup.url}" for i, (sup, name, why) in enumerate(final, 1)]
        # склеиваем в сообщения <= 4000 символов
        chunks, cur = [], header
        for it in items:
            block = it + "\n\n"
            if len(cur) + len(block) > 4000:
                chunks.append(cur)
                cur = ""
            cur += block
        chunks.append(cur)
        await edit(chunks[0].rstrip())
        for c in chunks[1:]:
            await send(c.rstrip())


if __name__ == "__main__":
    asyncio.run(ZakupBot().run())
