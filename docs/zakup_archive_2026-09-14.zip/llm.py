# -*- coding: utf-8 -*-
"""Запросы к GLM: разбор запроса пользователя в бриф, отбор и ранжирование результатов поиска."""
import json
import re

import httpx
from openai import OpenAI

import config

client = OpenAI(api_key=config.GLM_API_KEY, base_url="https://open.bigmodel.cn/api/paas/v4")


def _parse_json(text: str) -> dict:
    text = text.strip()
    m = re.search(r"\{.*\}", text, re.S)
    if m:
        text = m.group(0)
    return json.loads(text)


PARSE_SYSTEM = """Ты — парсер запросов для бота поиска поставщиков. Александр и Сергей просят найти поставщиков: исполнителей работ/услуг или продавцов материалов.
Верни ТОЛЬКО валидный JSON без markdown-обёртки:
{"type":"услуги","what":"стяжка пола","city":"Казань","volume":"200 м2","source":null}

Поля:
- "type": "услуги" — нужны исполнители работ/услуг (ремонт, отделка, стяжка, перевозка, электрика...); "материалы" — нужны поставщики товаров (кирпич, цемент, доски...).
- "what" — суть поиска короткой фразой, 2-5 слов ("стяжка пола", "кирпич облицовочный", "бригада отделочников").
- "city" — город/регион или null.
- "volume" — объём/количество/срок из запроса или null.
- "source" — ТОЛЬКО если пользователь прямо назвал площадку: "авито" -> "avito"; "яндекс услуги", "яндекс.услуги" -> "yandex_uslugi"; "в интернете", "по всему интернету", "везде" -> "web". Иначе null.
Если сообщение вообще не запрос на поиск (приветствие, «спасибо», «как дела», вопрос про бота) — верни {"chat": true}."""


def parse_request(text: str) -> dict:
    """Текст пользователя -> бриф поиска. При ошибке — безопасный дефолт."""
    try:
        resp = client.chat.completions.create(
            model=config.GLM_MODEL,
            messages=[
                {"role": "system", "content": PARSE_SYSTEM},
                {"role": "user", "content": text},
            ],
            temperature=0,
        )
        data = _parse_json(resp.choices[0].message.content)
    except Exception:
        data = {}
    return {
        "chat": bool(data.get("chat")),
        "type": data.get("type") if data.get("type") in ("услуги", "материалы") else "услуги",
        "what": (data.get("what") or text)[:100],
        "city": data.get("city") or None,
        "volume": data.get("volume") or None,
        "source": data.get("source") if data.get("source") in ("avito", "yandex_uslugi", "web") else None,
    }


RANK_SYSTEM = """Ты — редактор выдачи для бота поиска поставщиков. Пользователь ищет поставщиков по запросу, тебе дают результаты веб-поиска.
Отбери подходящие результаты и верни ТОЛЬКО валидный JSON без markdown-обёртки:
{"items":[{"i":3,"name":"ООО «СтяжкаПро»","why":"бригада по стяжке пола в Казани, есть отзывы"}]}

Правила:
- Отбрасывай: новости, статьи, отзывы, форумы, несоответствующие запросу страницы, дубли одной компании.
- Оставляй максимум 10 лучших, лучшие вперёд.
- "i" — номер результата в списке.
- "name" — чистое название компании или исполнителя из заголовка: без цены, без «| Avito», без «Объявления на тему...».
- "why" — одна короткая фраза (до 12 слов), что это за поставщик и почему подходит."""


def rank_results(brief: dict, suppliers: list) -> list[dict]:
    """Фильтрует и ранжирует результаты поиска. Возвращает [{"i": N, "name": ..., "why": ...}]."""
    if not suppliers:
        return []
    listing = "\n".join(
        f"{n}. {s.name} | {(s.description or '')[:150]} | {s.url}"
        for n, s in enumerate(suppliers, 1)
    )
    ask = (f"Запрос: тип={brief.get('type')}, что={brief.get('what')}, "
           f"город={brief.get('city') or 'не указан'}, объём={brief.get('volume') or 'не указан'}.\n\n"
           f"Результаты поиска:\n{listing}")
    try:
        resp = client.chat.completions.create(
            model=config.GLM_MODEL,
            messages=[
                {"role": "system", "content": RANK_SYSTEM},
                {"role": "user", "content": ask},
            ],
            temperature=0.2,
        )
        items = _parse_json(resp.choices[0].message.content).get("items", [])
    except Exception:
        return []
    valid = []
    for it in items:
        try:
            i = int(it.get("i"))
            if 1 <= i <= len(suppliers):
                valid.append({"i": i, "name": (it.get("name") or suppliers[i - 1].name)[:200],
                              "why": (it.get("why") or "")[:300]})
        except (TypeError, ValueError):
            continue
    return valid[:10]


CHAT_SYSTEM = """Ты — помощник внутри Telegram-бота поиска поставщиков для Александра и Сергея (строительство и бизнес).
Бот умеет: принимать запрос на поиск поставщиков (услуг или материалов) и выдавать список со ссылками,
показывать историю запросов (/zaprosy). Приём коммерческих предложений будет позже.
Отвечай по-русски, кратко (1-4 предложения), дружелюбно. Если сообщение похоже на запрос поиска —
подскажи просто написать его текстом, например: «Нужны исполнители по стяжке пола в Казани»."""


def chat(text: str) -> str:
    """Свободное общение для сообщений, не являющихся запросом на поиск."""
    resp = client.chat.completions.create(
        model=config.GLM_MODEL,
        messages=[
            {"role": "system", "content": CHAT_SYSTEM},
            {"role": "user", "content": text},
        ],
        temperature=0.6,
    )
    return resp.choices[0].message.content.strip()


def transcribe(audio: bytes, filename: str = "voice.ogg") -> str:
    """Расшифровка голосового (GLM-ASR). Возвращает текст."""
    r = httpx.post(
        "https://open.bigmodel.cn/api/paas/v4/audio/transcriptions",
        headers={"Authorization": f"Bearer {config.GLM_API_KEY}"},
        files={"file": (filename, audio, "audio/ogg")},
        data={"model": "glm-asr-2512"},
        timeout=120,
    )
    r.raise_for_status()
    return (r.json().get("text") or "").strip()
