# ZAKUP — Telegram-бот поиска поставщиков + трекер КП

Александр/Сергей пишут запрос («нужны исполнители по стяжке пола в Казани») → бот уточняет бриф и источник → ищет → выдаёт список поставщиков со ссылками. Всё пишется в Google Таблицу; веб-страница показывает запросы, статусы и результаты. Этап 2 (рассылка КП по почте, приём ответов) и этап 3 (MAX/Telegram-приём КП, глубокий парсинг Авито) — впереди.

## Архитектура
- Стек: Python, aiogram 3, aiohttp (веб + webhook), GLM `glm-5.3-flash` через OpenAI SDK (base_url bigmodel.cn), gspread, Jinja2.
- Секреты: `config_local.py`, `service_account.json` — в .gitignore, НЕ коммитить. Паттерн как в TBot: config_local → env-переменные.
- `llm.py`: `parse_request` — текст → бриф JSON {type, what, city, volume, source, chat}; `rank_results` — фильтр/ранжирование выдачи (LLM возвращает {"items":[{"i","name","why"}]}); `chat` — не-запросы; `transcribe` — голосовые (glm-asr-2512).
- Коннекторы (`searchers/`): стандарт «бриф → list[Supplier(name,url,description,source)]».
  - `yandex.py` — ОСНОВНОЙ: Yandex Search API v2 `POST https://searchapi.api.cloud.yandex.net/v2/web/search`, auth `Api-Key`, ответ XML, `site:`-оператор для avito.ru / uslugi.yandex.ru. Нужны YANDEX_SEARCH_API_KEY + YANDEX_FOLDER_ID (пробный лимит ~500 зап/сутки).
  - `glm_web.py` — запасной: `POST https://open.bigmodel.cn/api/paas/v4/web_search` (search_pro, search_domain_filter). Слаб на ру-инете, выдача шумная — только фолбэк.
  - Новый источник = новый модуль + строка в `searchers/base.py::SOURCES`.
- Sheets (лист «Запросы»): №, Дата, Автор, Запрос, Тип, Что искать, Город, Источники, Статус, Найдено, Примечание. Статусы: Новый → Поиск → Есть результаты / Нет результатов / Ошибка (этап 2 добавит КП-статусы; в «Поставщиках» колонка «Статус КП» уже есть). «Поставщики»: № запроса, Название, Описание, Ссылка, Источник, Статус КП, Заметки.
- Дашборд (`web/dashboard.py`): тот же процесс, вход по паролю DASHBOARD_PASSWORD (cookie), `/` — список запросов, `/request/{№}` — поставщики. Шаблоны `web/templates/`.
- Диалог бота: текст → бриф → кнопки источника (если не указан явно) → «Ищу…» → результаты (чанки ≤4000 симв). Голосовые распознаются. Доступ — заявка админу кнопками (как TBot), одобренные в листе «Пользователи».
- Поиск блокирующий → `asyncio.to_thread`. gspread-вызовы синхронные (как в TBot, приемлемо).
- Сервисный аккаунт Google: `tbot-678@api-project-985322515353.iam.gserviceaccount.com` (общий с TBot). У СА нулевая квота Drive — таблицу создаёт АЛЕКСАНДР в своём Drive и расшаривает СА; scripts/create_sheet.py больше не нужен.
- `scripts/test_search.py` — живой тест «бриф → поиск → ранжирование» без Telegram/Sheets.

## Инфраструктура (заполняется при деплое)
- GitHub: sankon13/zakup (TODO).
- Render free (TODO): env-vars полный список при PUT: TELEGRAM_BOT_TOKEN, GLM_API_KEY, GLM_MODEL, SPREADSHEET_ID, USERS, ADMIN_IDS, GOOGLE_CREDENTIALS, WEBHOOK_URL, DASHBOARD_PASSWORD, YANDEX_SEARCH_API_KEY, YANDEX_FOLDER_ID. PUT env-vars перезаписывает ВЕСЬ набор. Вебхук `/tgwebhook`, локально — polling. getUpdates-пробами не проверять (409).

## Грабли
- GLM web_search: search_domain_filter возвращает нерелевантное для ру-доменов; search_query ≤70 симв.
- Yandex API: ответ XML (raw_data), не JSON; максимум 10 групп… groupsOnPage 1-100, docsInGroup 1-3, maxPassages 1-5.
- У Voice нет file_name — getattr(m.voice, "file_name", None).

## Что дальше (дорожная карта)
1. Этап 2: рассылка КП (SMTP), приём ответов (IMAP, новая почта), разбор писем GLM, вложения → Drive, статусы КП.
2. Этап 3: приём КП в мессенджерах (MAX Bot API dev.max.ru — с авг.2025 нужен их «бизнес-режим»; Telegram), глубокий парсинг Авито.
