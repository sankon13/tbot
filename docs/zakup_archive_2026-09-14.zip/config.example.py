# -*- coding: utf-8 -*-
"""Шаблон локальных секретов. Скопируй в config_local.py и заполни (config_local.py не коммитится)."""
TELEGRAM_BOT_TOKEN = "123456:ABC..."            # токен от @BotFather
GLM_API_KEY = "xxxxxxxx.yyyyyyyy"               # ключ bigmodel.cn
GLM_MODEL = "glm-5.3-flash"
GOOGLE_SERVICE_ACCOUNT_FILE = "service_account.json"
SPREADSHEET_ID = "1AbC..."                      # Google Таблица «ZAKUP»
USERS = {
    597002771: "Александр",
}
ADMIN_IDS = [597002771]
DASHBOARD_PASSWORD = "секрет"                   # вход на веб-страницу статусов
