# -*- coding: utf-8 -*-
"""Одноразовая утилита: создаёт Google Таблицу ZAKUP, расшаривает пользователю, создаёт листы.

Запуск: python scripts/create_sheet.py [email_для_доступа]
Если email не указан — берётся из разрешений таблицы TBot (та же учётка).
"""
import sys

import gspread

import config

gc = gspread.service_account(filename=config.GOOGLE_SERVICE_ACCOUNT_FILE)

email = sys.argv[1] if len(sys.argv) > 1 else None
if not email:
    try:
        tbot = gc.open_by_key("1wpJQbO0VS-qW0fxWqYGArceqXem465x-g3aS49__BrI")
        for p in tbot.list_permissions():
            if p.get("emailAddress") and not p["emailAddress"].endswith("gserviceaccount.com"):
                email = p["emailAddress"]
                break
        print("email из разрешений TBot:", email)
    except Exception as e:
        print("не удалось прочитать разрешения TBot:", e)

sh = gc.create("ZAKUP: поставщики и КП")
if email:
    sh.share(email, perm_type="user", role="writer")
    print("расшарено:", email)
print("SPREADSHEET_ID =", sh.id)
